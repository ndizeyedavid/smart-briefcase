import SideBar from '../components/SideBar'
import Header from '../components/Header'
import Container from '../components/Container'
import Map from '../components/Map'
const Track = () => {
    return (
        <>
            <SideBar />
            <Header />
            <Container>
                <Map />
            </Container>
        </>
    )
}
export default Track