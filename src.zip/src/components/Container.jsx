
const Container = ({ children }) => {
    return (
        <>
            <div className="ml-[236px] z-[0] w-[84%] h-[600px] p-4 mt-20">
                <div className="w-full h-full shadow-lg card">
                    {/* <button className="btn hover:bg-yellow-500">ads</button> */}
                    {children}
                </div>
            </div>
        </>
    )
}

export default Container
