import { useEffect, useState } from 'react';
import Alert from './Alert'
import Notification from './Notification'

const Header = () => {
    function getCurrentPage() {
        let pathname = window.location.pathname;
        pathname = pathname.split('/')[1];
        if (pathname == '') {
            document.getElementById('pageName').innerText = "Track";
        } else {
            document.getElementById('pageName').innerText = pathname;
        }
        // console.log(pathname)
    }
    setTimeout(getCurrentPage, 100)

    const [notifcation, setNotification] = useState([]);
    useEffect(() => {

        const fetchNotification = async () => {
            const result = await fetch(import.meta.env.VITE_HOST_ADDRESS + '/notifications/view')
                .then(d => {
                    const result = d.json()
                        .then(data => {
                            const out = data.cont;
                            const not = []
                            for (let i = 0; i < out.length; i++) {
                                not.push(out[i].details)
                            }
                            setNotification(not);
                            // setProfile(out.profile);
                            // console.log(data.cont[0])
                        })
                })
        }


        fetchNotification()
    })

    return (
        <>
            <header className='absolute w-[84%] top-1 mx-3 right-0 shadow-sm bg-white font-[sans-serif] min-h-[70px]'>
                <div
                    className='relative flex flex-wrap items-center justify-between w-full px-6 py-3 sm:px-10 lg:gap-y-4 gap-y-6 gap-x-4'>

                    <div className="flex">

                        <div className="text-sm breadcrumbs">
                            <h3 className="text-xl font-bold capitalize" id='pageName'></h3>
                        </div>
                    </div>

                    <div className="flex rounded-sm max-md:order-1 h-11 lg:w-2/4 max-md:w-full">

                        <Alert type="success" />

                    </div>

                    <div className='flex items-center space-x-8 max-md:ml-auto'>

                        <Notification notifs={notifcation} />
                    </div>
                </div>
            </header>
        </>
    )
}

export default Header
